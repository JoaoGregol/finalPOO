
package persistencia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import static javax.swing.JOptionPane.showMessageDialog;
import modelo.Tarefa;

public class JDBCTarefa {
    Connection conexao;

    public JDBCTarefa(Connection conexao) {
        this.conexao = conexao;
    }

    public void inserirTarefa(Tarefa t){
        String sql = "insert into tarefa(nome, funcao, concluido) values (?, ?, ?)";
        PreparedStatement ps;

        try {
            ps = this.conexao.prepareStatement(sql);
            ps.setString(1, t.getNome());
            ps.setString(2, t.getFuncao());
            ps.setBoolean(3, t.isConcluido());
            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    public ArrayList<Tarefa> listarTarefas(){
        ArrayList<Tarefa> tarefas = new ArrayList<Tarefa>();
        String sql = "select * from tarefa";
        
         try {
            Statement declaração = conexao.createStatement();
            ResultSet resposta = declaração.executeQuery(sql);
            
            while(resposta.next()) {
                int id = resposta.getInt("id");
                String nome = resposta.getString("nome");
                String funcao = resposta.getString("funcao");
                boolean concluido = resposta.getBoolean("concluido");
                
                Tarefa t = new Tarefa(id, concluido, nome, funcao);
                tarefas.add(t);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return tarefas;
    }
    
    public Tarefa buscarPorId(String id) {
        Tarefa t = new Tarefa();
        String sql = "select * from tarefa where id =" +   id;
        
        try {
            Statement declaração = conexao.createStatement();
            ResultSet resposta = declaração.executeQuery(sql);
            
            while(resposta.next()) {
                String nome = resposta.getString("nome");
                String funcao = resposta.getString("funcao");
                boolean concluido = resposta.getBoolean("concluido");
                
                t = new Tarefa(concluido, nome, funcao);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return t;
    }
    public void atualizarTarefa(Tarefa t){
        String sql = "update tarefa set nome = ?, funcao = ?, concluido = ? where id = ?";
        PreparedStatement ps;
        
        try {
            ps = this.conexao.prepareStatement(sql);
            ps.setString(1, t.getNome());
            ps.setString(2, t.getFuncao());
            ps.setBoolean(3, t.isConcluido());
            ps.setInt(4, t.getId());
            ps.execute();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }

    
}


