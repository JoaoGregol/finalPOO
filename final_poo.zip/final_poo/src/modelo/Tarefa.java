package modelo;


public class Tarefa {
    private int id;
    private boolean concluido;
    private String nome;
    private String funcao;

    public Tarefa(int id, boolean concluido, String nome, String funcao) {
        this.id = id;
        this.concluido = concluido;
        this.nome = nome;
        this.funcao = funcao;
    }
    public Tarefa( boolean concluido, String nome, String funcao) {
        this.concluido = concluido;
        this.nome = nome;
        this.funcao = funcao;
    }
     public Tarefa(){};
  

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isConcluido() {
        return concluido;
    }

    public void setConcluido(boolean concluido) {
        this.concluido = concluido;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
}
